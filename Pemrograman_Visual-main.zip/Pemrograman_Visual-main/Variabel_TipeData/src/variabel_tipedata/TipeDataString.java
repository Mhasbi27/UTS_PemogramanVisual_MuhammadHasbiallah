package variabel_tipedata;

public class TipeDataString {
    
    public static void main (String[] args) {
        
        String var1 = "Saya Sedang Belajar ";
        String var2 = "Java";
        String var3 = "Saya belajar\nbahasa pemrograman \"Java\"";
        
        System.out.print(var1);
        System.out.print(var2);
        System.out.println("");
        System.out.println(var1+var2);
        System.out.println("");
        System.out.println(var3);
    }
}
